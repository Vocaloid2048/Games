package voc.net.cmthk.games;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import static android.content.pm.PackageManager.GET_META_DATA;
import static voc.net.cmthk.games.LocaleManager.LANGUAGE_CHINESE_IN_CHINA;
import static voc.net.cmthk.games.LocaleManager.LANGUAGE_CHINESE_IN_HONG_KONG_SAR_CHINA;
import static voc.net.cmthk.games.LocaleManager.LANGUAGE_CHINESE_IN_TAIWAN;

public abstract class BaseActivity extends AppCompatActivity {

    private static final String TAG = "BaseActivity";
    private int rCN;
    private int rHK;
    private int rTW;


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext( LocaleManager.setLocale(base));
        Log.d(TAG, "attachBaseContext");
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        resetTitles();
    }

    private void resetTitles() {
        try {
            ActivityInfo info = getPackageManager().getActivityInfo(getComponentName(), GET_META_DATA);
            if (info.labelRes != 0) {
                setTitle(info.labelRes);
            }
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        showResourcesInfo();
        showTitleCache();
    }

    private void showResourcesInfo() {
        Resources topLevelRes = getTopLevelResources();
        updateInfo("Top level  ", (TextView) findViewById( R.id.tv1), topLevelRes);

        Resources appRes = getApplication().getResources();
        updateInfo("Application  ", (TextView) findViewById(R.id.tv2), appRes);

        Resources actRes = getResources();
        updateInfo("Activity  ", (TextView) findViewById(R.id.tv3), actRes);

        TextView tv4 = findViewById(R.id.tv4);
        String defLanguage = Locale.getDefault().getLanguage();
        tv4.setText( String.format("Locale.getDefault() - %s", defLanguage));
        tv4.setCompoundDrawablesWithIntrinsicBounds(null, null, getLanguageDrawable(defLanguage), null);
    }

    private Resources getTopLevelResources() {
        try {
            return getPackageManager().getResourcesForApplication(getApplicationInfo());
        } catch (NameNotFoundException e) {
            throw new RuntimeException (e);
        }
    }

    private void updateInfo(String title, TextView tv, Resources res) {
        Locale l = LocaleManager.getLocale(res);
        tv.setText(title + Utility.hexString(res) + String.format(" - %s", l.getLanguage()));
        Drawable icon = getLanguageDrawable(l.getLanguage());
        tv.setCompoundDrawablesWithIntrinsicBounds(null, null, icon, null);
    }

    @SuppressWarnings("unchecked")
    private void showTitleCache() {
        Object o = Utility.getPrivateField("android.app.ApplicationPackageManager", "sStringCache", null);
        Map<?, WeakReference<CharSequence>> cache = (Map<?, WeakReference<CharSequence>>) o;
        if (cache == null) return;

        StringBuilder builder = new StringBuilder ("Cache:").append("\n");
        for (Entry<?, WeakReference<CharSequence>> e : cache.entrySet()) {
            CharSequence title = e.getValue().get();
            if (title != null) {
                builder.append(title).append("\n");
            }
        }
        TextView tv = findViewById(R.id.cache);
        tv.setText(builder.toString());
    }

    private Drawable getLanguageDrawable(String language) {
        switch (language) {
            case LANGUAGE_CHINESE_IN_CHINA:
                return ContextCompat.getDrawable(this, R.drawable.language_zh-rCN);
            case LANGUAGE_CHINESE_IN_HONG_KONG_SAR_CHINA:
                return ContextCompat.getDrawable(this, R.drawable.language_zh-rHK);
            case LANGUAGE_CHINESE_IN_TAIWAN:
                return ContextCompat.getDrawable(this, R.drawable.language_zh-rTW);
            default:
                Log.w(TAG, "Unsupported language");
                return null;
        }
    }
}