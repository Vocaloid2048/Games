package voc.net.cmthk.games;

import android.media.AudioManager;
import android.media.SoundPool;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class GamePage3Activity extends AppCompatActivity implements View.OnClickListener{

    Button mButton;      //定义成全局变量，保存 Button 对象，便于全局调用
    TextView mTextView;  //定义成全局变量，保存 TextView 对象，便于全局调用
    int textInTextView;  //定义成全局变量，保存 TextView 中的值，便于调用
    int textInTextView2; //定义成全局变量，保存 TextView 中的值，便于调用
    ImageView mImageView;//定义成全局变量，保存 ImageView 对象，便于调用
    TextView mTextView2; //定义成全局变量，保存 TextView 中的值，便于调用
    TextView mTextView3; //定义成全局变量，保存 TextView 中的值，便于调用
    TextView mTextView4; //定义成全局变量，保存 TextView 中的值，便于调用
    private SoundPool sp;//声明一个SoundPool
    private int music;//定义一个整型用load（）；来设置suondID

    final int[] imageViews = {
            R.drawable.fire_eveee,R.drawable.fairy_eveee,R.drawable.water_eveee,
            R.drawable.ice_eveee,R.drawable.thun_eveee,R.drawable.moon_eveee,
            R.drawable.sun_eveee,R.drawable.leaf_eveee};

    final int[] images = {
            R.string.fire_e,R.string.fairy_e,R.string.water_e,
            R.string.ice_e,R.string.thun_e,R.string.moon_e,
            R.string.sun_e,R.string.leaf_e};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_page3);
        mTextView = (TextView)findViewById(R.id.textView8);//绑定控件，获取实例
        mTextView.setText("0"); //初始化 TextView 中的值为 0
        mButton = (Button)findViewById(R.id.bt_num);  //绑定控件，获取实例
        mButton.setOnClickListener(this);  //注册点击事件
        mImageView = (ImageView)findViewById (R.id.img1);
        mTextView2 = (TextView)findViewById(R.id.textView4);
        mTextView3 = (TextView)findViewById(R.id.textView12);
        mTextView4 = (TextView)findViewById(R.id.textView11);
        sp= new SoundPool(10, AudioManager.STREAM_SYSTEM, 5);//第一个参数为同时播放数据流的最大个数，第二数据流类型，第三为声音质量
        music = sp.load(this, R.raw.press_button_game, 1); //把你的声音素材放到res/raw里，第2个参数即为资源文件，第3个为音乐的优先级
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.bt_num:
                sp.play(music, 1, 1, 0, 0, 1);
                textInTextView = Integer.parseInt(mTextView.getText().toString());
                //我们要的时 int 值，因为我们要做数学运算
                //而通过 getText() 获取的值是 byte 类型的，
                //需要调用 .toString 转换成 String 型
                //然后通过 Integer.getInteger() 方法将获取到的值转换成整型。
                textInTextView++;  //自加
                mTextView.setText(Integer.toString(textInTextView));
                //将结果显示到 TextView 上
                //由于 setText() 需要传入一个字符串，
                //所以要调用 Integer.toString 方法把数字转换成字符串，再传入
                if (textInTextView2 == 2){
                    textInTextView = 0;
                    mTextView.setText(Integer.toString(textInTextView));
                }
                break;
            case R.id.btn_reset:
                sp.play(music, 1, 1, 0, 0, 1);
                if (textInTextView>=100) {
                    textInTextView = 0;
                    mTextView.setText ( "0" );
                    Toast.makeText ( GamePage3Activity.this, "升級", Toast.LENGTH_SHORT ).show ();
                    textInTextView2 = Integer.parseInt(mTextView3.getText().toString());
                    //我们要的时 int 值，因为我们要做数学运算
                    //而通过 getText() 获取的值是 byte 类型的，
                    //需要调用 .toString 转换成 String 型
                    //然后通过 Integer.getInteger() 方法将获取到的值转换成整型。
                    textInTextView2++;  //自加
                    mTextView3.setText(Integer.toString(textInTextView2));
                    if (textInTextView2 == 1){
                        mImageView.setImageResource (R.drawable.pkc);
                        mTextView2.setText (R.string.pkc);
                    }else if (textInTextView2 == 2){
                        mImageView.setImageResource (R.drawable.lc);
                        mTextView2.setText (R.string.lc);
                        textInTextView = 0;
                        mTextView4.setText ("0");
                        Toast.makeText(GamePage3Activity.this, "已升級至最高", Toast.LENGTH_SHORT).show();
                    }

                } else if (textInTextView <100) {Toast.makeText(GamePage3Activity.this, "不足以升級", Toast.LENGTH_SHORT).show();}
                break;
            default:
                break;
        }
    }
}