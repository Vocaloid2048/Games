package voc.net.cmthk.games;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.util.Calendar;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    private static final int msgKey1 = 1;
    private TextView mTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        mTime = (TextView) findViewById(R.id.mytime);
        new TimeThread().start();
    }
    public class TimeThread extends Thread {
        @Override
        public void run () {
            do {
                try {
                    Thread.sleep(1000);
                    Message msg = new Message();
                    msg.what = msgKey1;
                    mHandler.sendMessage(msg);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while(true);
        }
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage (Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case msgKey1:
                    mTime.setText(getTime());
                    break;
                default:
                    break;
            }
        }
    };
    //获得当前年月日时分秒星期
    public String getTime(){
        final Calendar c = Calendar.getInstance();
        c.setTimeZone( TimeZone.getTimeZone("GMT+8:00"));
        String mYear = String.valueOf(c.get(Calendar.YEAR)); // 获取当前年份
        String mMonth = String.valueOf(c.get(Calendar.MONTH) + 1);// 获取当前月份
        String mDay = String.valueOf(c.get(Calendar.DAY_OF_MONTH));// 获取当前月份的日期号码
        String mWay = String.valueOf(c.get(Calendar.DAY_OF_WEEK));

        if("1".equals(mWay)){
            mWay ="日";
        }else if("2".equals(mWay)){
            mWay ="一";
        }else if("3".equals(mWay)){
            mWay ="二";
        }else if("4".equals(mWay)){
            mWay ="三";
        }else if("5".equals(mWay)){
            mWay ="四";
        }else if("6".equals(mWay)){
            mWay ="五";
        }else if("7".equals(mWay)){
            mWay ="六";
        }
        return "\n" + "\n"+ "\n" +mYear + "年" + mMonth + "月" + mDay+"日"+"  "+"星期"+mWay;
    }
    public void gotosetting(View view) {
        Intent intent = new Intent ( this, SettingActivity.class );
        startActivity ( intent );
    }
    public void gotohomeing(View view) {
        Intent intent = new Intent ( this, HomingActivity.class );
        startActivity ( intent );
    }
    public void gotogame(View view) {
        Intent intent = new Intent ( this, GameChooseActivity.class );
        startActivity ( intent );
    }
    public void gotosnow(View view) {
        Intent intent = new Intent ( this, SnowActivity.class );
        startActivity ( intent );
    }
    public void gotorain(View view) {
        Intent intent = new Intent ( this, RainActivity.class );
        startActivity ( intent );
    }
    public void gotometeor(View view) {
        Intent intent = new Intent ( this, MeteorActivity.class );
        startActivity ( intent );
    }
}
