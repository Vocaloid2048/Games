package voc.net.cmthk.games;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * 雪花的类, 移动, 移出屏幕会重新设置位置.
 */
public class SnowActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_snow );
    }
}