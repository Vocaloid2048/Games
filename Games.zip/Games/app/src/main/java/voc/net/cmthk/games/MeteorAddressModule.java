package voc.net.cmthk.games;

/**
 * Created by Administrator on 2016/6/11.
 */
public class MeteorAddressModule {

    private float mX = 0;
    private float mY = 0;

    public float getmX() {
        return mX;
    }

    public void setmX(float mX) {
        this.mX = mX;
    }

    public float getmY() {
        return mY;
    }

    public void setmY(float mY) {
        this.mY = mY;
    }
}
