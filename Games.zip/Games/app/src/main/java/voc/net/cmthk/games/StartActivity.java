package voc.net.cmthk.games;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class StartActivity extends Activity{
    private static final int LOADING=1;
    private static final int LOADING_COMPLETE=2;
    private static final int OPEN=3;

    int i = 0;
    ProgressBar progressBar = null;
    Button button = null;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case LOADING:
                    button.setEnabled(false);
                    i += 5;
                    progressBar.setProgress(i);
                    if (i != 100) {
                        mHandler.sendEmptyMessageDelayed(LOADING, 100);
                        button.setText("已加載"+i+"%...");
                    } else if (i == 100) {
                        button.setText("加載完成");
                        mHandler.sendEmptyMessageDelayed(LOADING_COMPLETE, 500);
                    }
                    break;
                case LOADING_COMPLETE:
                    button.setText("開啟遊戲界面");
                    button.setEnabled(true);
                    button.setBackgroundResource(android.R.color.holo_orange_light);
                    mHandler.sendEmptyMessageDelayed(OPEN, 500);
                    Intent intent = new Intent();
                    intent.setClass(StartActivity.this, MainActivity.class);
                     startActivity(intent);
                    break;
                case OPEN:
                    progressBar.setProgress(0);
                    button.setBackgroundResource(R.drawable.btn_selewctor);
                    button.setText("加載遊戲");
                    break;
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView( R.layout.activity_start);
        //mHandler2.sendEmptyMessageDelayed(GOTO_MAIN_ACTIVITY, 4000); //2秒跳轉

        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = 0;
                mHandler.sendEmptyMessage(LOADING);
            }
        });
    }
    public void click(View view){
        Toast toast = Toast.makeText(getApplicationContext(),
                "要是對我的名字有*異議*，就說出來吧!",
                Toast.LENGTH_LONG);

        toast.show();
    }

    //private static final int GOTO_MAIN_ACTIVITY = 0;
    //private Handler mHandler2 = new Handler() {
        //public void handleMessage(android.os.Message msg) {

            //switch (msg.what) {
                //case GOTO_MAIN_ACTIVITY:
                   // Intent intent = new Intent();
                    //將原本Activity的換成MainActivity
                   // intent.setClass(StartActivity.this, MainActivity.class);
                   // startActivity(intent);
                   // finish();
                    //break;

                //default:
                 //   break;
         //   }
      //  }

   // };
}