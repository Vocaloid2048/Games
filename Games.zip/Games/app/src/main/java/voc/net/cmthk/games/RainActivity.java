package voc.net.cmthk.games;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class RainActivity extends AppCompatActivity {

    private SoundPool sp2;//声明一个SoundPool
    private int music;//定义一个整型用load（）；来设置suondID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_rain );
        sp2= new SoundPool(1, AudioManager.STREAM_SYSTEM, 5);//第一个参数为同时播放数据流的最大个数，第二数据流类型，第三为声音质量
        music = sp2.load(this, R.raw.rain_layout, 1); //把你的声音素材放到res/raw里，第2个参数即为资源文件，第3个为音乐的优先级
        sp2.play(music, 1, 1, 0, 100, 1);
    }
}
