package voc.net.cmthk.games;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class GameChooseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_game_choose );
    }
    public void eveee(View view) {
        Intent intent = new Intent ( this, GameMainActivity.class );
        startActivity ( intent );
    }
    public void bkm(View view) {
        Intent intent = new Intent ( this, GamePage2Activity.class );
        startActivity ( intent );
    }
    public void pic(View view) {
        Intent intent = new Intent ( this, GamePage3Activity.class );
        startActivity ( intent );
    }
    public void rhy(View view) {
        Intent intent = new Intent ( this, GamePage4Activity.class );
        startActivity ( intent );
    }
}
