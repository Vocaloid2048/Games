package voc.net.cmthk.games;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

import java.util.ArrayList;
import java.util.List;

public class HomingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_homing );

        List<Member> memberList = new ArrayList<> ();
        memberList.add(new Member(1, R.drawable.basic_eveee, " "));
        memberList.add(new Member(2, R.drawable.fire_eveee, " "));
        memberList.add(new Member(3, R.drawable.fairy_eveee, " "));
        memberList.add(new Member(4, R.drawable.ice_eveee, " "));
        memberList.add(new Member(5, R.drawable.water_eveee, " "));
        memberList.add(new Member(6, R.drawable.moon_eveee, " "));
        memberList.add(new Member(7, R.drawable.sun_eveee, " "));
        memberList.add(new Member(8, R.drawable.leaf_eveee, " "));
        memberList.add(new Member(9, R.drawable.thun_eveee, " "));
        memberList.add(new Member(10, R.drawable.bkm, " "));
        memberList.add(new Member(11, R.drawable.bwz, " "));
        memberList.add(new Member(12, R.drawable.dwnb, " "));
        memberList.add(new Member(13, R.drawable.pic, " "));
        memberList.add(new Member(14, R.drawable.pkc, " "));
        memberList.add(new Member(15, R.drawable.lc, " "));
        memberList.add(new Member(16, R.drawable.rhyhorn, " "));
        memberList.add(new Member(17, R.drawable.rhydon, " "));
        memberList.add(new Member(18, R.drawable.rhyperior, " "));



        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager (1, StaggeredGridLayoutManager.VERTICAL));
// MemberAdapter 會在步驟7建立
        recyclerView.setAdapter(new MemberAdapter(this, memberList));
    }
    }

